// Implement a click on todo item as fast as possible
