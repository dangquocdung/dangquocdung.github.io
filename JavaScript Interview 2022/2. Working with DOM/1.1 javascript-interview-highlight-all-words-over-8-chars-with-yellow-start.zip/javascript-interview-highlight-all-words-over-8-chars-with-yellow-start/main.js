// Highlight all of the words over 8 characters long in the paragraph text (with a yellow background for example)
