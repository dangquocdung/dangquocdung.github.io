// Create a es6 module with function getName, getSurname and default export getFullname.
// Create the same with commonJS module
// What is the difference?
