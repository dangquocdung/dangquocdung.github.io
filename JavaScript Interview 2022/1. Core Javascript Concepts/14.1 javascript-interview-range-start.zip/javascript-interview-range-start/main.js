// Write a function which implement range

// range(1, 50)
// 1,2,3,4,5,6,...,50
