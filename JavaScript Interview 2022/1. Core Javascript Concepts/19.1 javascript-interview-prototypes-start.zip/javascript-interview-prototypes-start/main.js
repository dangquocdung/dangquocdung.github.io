// Design the same classes by using only Javascript prototypes
