// Create debounce function
