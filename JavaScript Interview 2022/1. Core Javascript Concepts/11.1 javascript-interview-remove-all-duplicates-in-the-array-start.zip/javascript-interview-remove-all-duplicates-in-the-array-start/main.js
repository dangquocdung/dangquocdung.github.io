// Remove all duplicates in the array
