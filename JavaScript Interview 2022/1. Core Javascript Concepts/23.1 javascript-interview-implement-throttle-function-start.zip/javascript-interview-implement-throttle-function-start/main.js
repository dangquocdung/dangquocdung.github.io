// Create throttle function
