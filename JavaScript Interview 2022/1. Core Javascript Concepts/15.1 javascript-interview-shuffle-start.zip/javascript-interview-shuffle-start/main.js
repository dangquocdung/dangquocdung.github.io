// Write a function which implements shuffle
